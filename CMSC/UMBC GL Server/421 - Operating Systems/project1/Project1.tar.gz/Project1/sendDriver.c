#include <stdio.h>
#include <stdlib.h>
#include <syscall.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

/*
  Christopher Mai
  chrmai1
  section 1? there's only 1 section
  Keycode: PRJ1
 */


long mkMbox421(unsigned long mbxID);

long rmMbox421(unsigned long mbxID);

long countMbox421();

long listMbox421(unsigned long *mbxList, unsigned long K);

long sendMsg421(unsigned long mbxID, char *msg, unsigned long N);

long receiveMsg421(unsigned long mbxID, char *msg, unsigned long N, unsigned char flag);

long countMsg421(unsigned long mbxID); 

int main(int argc, char *argv[])
{


  if(argc != 2){
    printf("Improper # of cmd line args. Takes in mailbox ID");
    return -1;
  }
  
  /*
    Just a mailbox. 
    Nothing happens if it already exists anyway
   */
  
  int mbxID = atoi(argv[1]);


  if(mbxID < 0 || mbxID > 255){
    printf("Invalid ID. Accepts 0-255\n");

    return -1;
  }

  printf("ID: %d\n", mbxID);

  if(mkMbox421(mbxID) == -1){
    fprintf(stderr, "errno: %s\n", strerror(errno));
  }

  printf("Print your message(Input continues until you hit ctrl+d):\n");

  int x = 0;
  char read;
  char message[512];

  read = getchar();

  while(read != EOF){
    message[x] = read;
    read = getchar();
    x++;
  }

  /* works perfectly */
  int sent = sendMsg421(mbxID, message, strlen(message));

  if(sent == -1){
    fprintf(stderr, "errno: %s\n", strerror(errno));
  } else {
    fprintf(stderr, "\nNum chars sent: %d\n", sent);
    printf("Message: %s\n", message);
    /*
    for(x = 0; x < sent; x++){
      printf("%c", message[x]);
      }*/
  }
  return 0;
}


long mkMbox421(unsigned long mbxID)
{
  return syscall(__NR_mkMbox421, mbxID);
}

long rmMbox421(unsigned long mbxID)
{
  return syscall(__NR_rmMbox421, mbxID);
}

long countMbox421()
{
  return syscall(__NR_countMbox421);
}

long listMbox421(unsigned long *mbxList, unsigned long K)
{
  
  long rawr = syscall(__NR_listMbox421, mbxList, K);

  return rawr;
}

long sendMsg421(unsigned long mbxID, char *msg, unsigned long N)
{
  return syscall(__NR_sendMsg421, mbxID, msg, N);
}

long receiveMsg421(unsigned long mbxID, char *msg, unsigned long N,
		   unsigned char flag)
{
  return syscall(__NR_receiveMsg421, mbxID, msg, N, flag);
} 

long countMsg421(unsigned long mbxID)
{
  return syscall(__NR_countMsg421, mbxID);
}
