#include <stdio.h>
#include <stdlib.h>
#include <syscall.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

/*
  Christopher Mai
  chrmai1
  Section 1 
  PRJ1
 */

long mkMbox421(unsigned long mbxID);

long rmMbox421(unsigned long mbxID);

long countMbox421();

long listMbox421(unsigned long *mbxList, unsigned long K);

long sendMsg421(unsigned long mbxID, char *msg, unsigned long N);

long receiveMsg421(unsigned long mbxID, char *msg, unsigned long N, unsigned char flag);

long countMsg421(unsigned long mbxID); 

int main(int argc, char *argv[])
{
  if(argc != 4){
    printf("Invalid Number of cmd line args: mbxID, N, flag\n");

    return 0;
  }

  int mbxID = atoi(argv[1]);
  
  printf("ID: %d\n", mbxID);

  if(mbxID < 0 || mbxID > 255){
    printf("Invalid mbxID: 0 - 255\n");
  }

  int n = atoi(argv[2]);
  
  if(n < 0 || n > 512){
    printf("Invalid n number. msg length 0-512\n");
  }

  int flag = atoi(argv[3]);

  char message[512];

  int recv = receiveMsg421(mbxID, message, n, flag);

  if(recv == -1){
    fprintf(stderr, "errno: %s\n", strerror(errno));
  } else {
    fprintf(stderr, "Num received: %d\n", recv);
    printf("Message: %s\n", message);
  }
  
  /*
    The receiveDriver takes three command-line arguments: mbxID, N, and flag.
    The driver is to receive up to N characters from the next message in the
    mailbox mbxID, and remove from the message from the mailbox if flag is
    positive. It informs the user on stderr of the number K of characters
    successfully received, and then it prints on stdout the contents of the
    message received. It prints an appropriate error message on stderr if an
    error occurred. 
  */
  
  return 0;
}


long mkMbox421(unsigned long mbxID)
{
  return syscall(__NR_mkMbox421, mbxID);
}

long rmMbox421(unsigned long mbxID)
{
  return syscall(__NR_rmMbox421, mbxID);
}

long countMbox421()
{
  return syscall(__NR_countMbox421);
}

long listMbox421(unsigned long *mbxList, unsigned long K)
{
  
  long rawr = syscall(__NR_listMbox421, mbxList, K);

  return rawr;
}

long sendMsg421(unsigned long mbxID, char *msg, unsigned long N)
{
  return syscall(__NR_sendMsg421, mbxID, msg, N);
}

long receiveMsg421(unsigned long mbxID, char *msg, unsigned long N,
		   unsigned char flag)
{
  return syscall(__NR_receiveMsg421, mbxID, msg, N, flag);
} 

long countMsg421(unsigned long mbxID)
{
  return syscall(__NR_countMsg421, mbxID);
}
