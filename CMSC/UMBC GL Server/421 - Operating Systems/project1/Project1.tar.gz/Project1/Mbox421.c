#include <linux/syscalls.h>
#include <asm/uaccess.h>
#include <linux/rwsem.h>

/*
  Christopher Mai
  chrmai1
  Section 1
  PRJ1
 */

typedef struct mailbox
{
  int open;
  char mail[128][512];
  /*
    [128] mailbox numbers
    [512] string numbers
   */
}MAIL;

 MAIL mailbox[256];

asmlinkage long sys_hello421()
{
  printk("Hello World 421!? Receive Revisions\n");

  return 0;
}


asmlinkage long sys_mkMbox421(unsigned long mbxID)
{

  int x = 0;
  int y = 0;

  struct rw_semaphore semaphore;
  
  if(mbxID < 0 || mbxID > 255){
    /* invalid ID */
  
    return 0;
  }
  
  
  
  init_rwsem(&semaphore);
 
  down_write(&semaphore);
 
  /* check if mailbox already open */ 
		      
  if(mailbox[mbxID].open == 1){
    printk("mailbox already open\n");
  } else {
    printk("mailbox open");
    mailbox[mbxID].open = 1;
    
    /*  initialize the members */ 
    for(x = 0; x < 128; x++){
      for(y = 0; y < 512; y++){
	mailbox[mbxID].mail[x][y] = '\0'; 
      }
    }
  }
  
  up_write(&semaphore);
   
  return 0;
}
  
asmlinkage long sys_rmMbox421(unsigned long mbxID)
{
  struct rw_semaphore semaphore;
  
  if(mbxID < 0 || mbxID > 255){
    /* Invalid ID */ 
       return 1;
  }
  
  
  init_rwsem(&semaphore);

  down_write(&semaphore);

  if(mailbox[mbxID].open == 1){
    /* mailbox open check for still existing mail */
    if(mailbox[mbxID].mail[0][0] == '\0'){
      /* mailbox empty */
      mailbox[mbxID].open = 0;
    }
  }
 
  up_write(&semaphore);

  return 0;
}

asmlinkage long sys_countMbox421()
{
  struct rw_semaphore semaphore;
  
  int x = 0;
  int counter = 0;

  init_rwsem(&semaphore);
  
  down_write(&semaphore);
  
  for(x = 0; x < 256; x++){
    if(mailbox[x].open == 1){
      /* Possible options: NULL or OPEN */
      counter++;
    }
  }

  up_write(&semaphore);

  return counter;
}


/*
  requires access_ok and
  copy_to_user
 */
asmlinkage long sys_listMbox421(unsigned long *mbxList, unsigned long k)
{
  struct rw_semaphore semaphore;

  unsigned long tempmbx[256]; 

  int x = 0;
  int counter = 0;

  init_rwsem(&semaphore);

  down_write(&semaphore);

  if(k < 0 || k > 128){
    printk("List: improper number of boxes. k > 0 && k <= 128\n");

    up_write(&semaphore);

    return 0;
  }
 
  for(x = 0; x < 256; x++){
    /* only check if I don't exceed the given limit */
    if(counter < k){
      /* Mailbox exists */
      if(mailbox[x].open == 1){
	/* X by nature matches the ID  */
	tempmbx[counter] = x;
	
	counter++;
      }
    }
  }

  
  if(access_ok(VERIFY_WRITE, mbxList, sizeof(long) * k) != 0){
    /* Alright to write  */
    /* sizeof(long) * k */
     copy_to_user(mbxList, &tempmbx, sizeof(long) * k);
     /* printk("List: print list - %s\n", tempmbx); */
     for(x = 0; x < counter; x++){
       printk("Inside Mail#: %ld\n", tempmbx[x]);
     }
     printk("Counter: %d\n", counter);
     printk("List of open boxes\n");
     
     for(x = 0; x < counter; x++){
       printk("Mailbox Number: %lu\n", mbxList[x]);
     }
  } else {
    up_write(&semaphore);
     return 0;
   }

  
  
   up_write(&semaphore);

   return counter;
}


/*
  requires access_ok and
  copy_from_user/copy_to_user
 */
asmlinkage long sys_sendMsg421(unsigned long mbxID, char *msg, unsigned long N)
{
  struct rw_semaphore semaphore;

  char tmsg[512];

  int bookmark = 0;

  int x = 0;
  
  int flag = 0;

  init_rwsem(&semaphore);

  down_write(&semaphore);

  if(N < 0 || N > 512){
    printk("Send: Improper number of chars. N > 0 && N <= 512\n");

    up_write(&semaphore);

    return 0;
  }

  if(access_ok(VERIFY_READ, msg, sizeof(msg) * N) != 0){
    printk("Send: access ok. msg: %s\n", msg);
    copy_from_user(tmsg, msg, sizeof(msg) * N);
    printk("Send: tmsg: %s\n", tmsg);
  } else {    
    printk("Send: access not ok\n");
    up_write(&semaphore);
    return 0;
  }

  /* check mailbox exists */
  if(mbxID < 0 || mbxID > 255) {
    /* Invalid ID  */
    printk("Send: Invalid ID\n");
    up_write(&semaphore);
    return 0;
  } else
    if(mailbox[mbxID].open != 1) {
      /* Mailbox Closed Can't send  */
      printk("Send: mailbox closed. can't send \n");
    } else {
      printk("Send: mailbox open. can send\n");
      /*
	ID Valid and Mailbox OPEN
	check for open space in mailbox
      */
      /* x becomes 1 at start of loop */
     
      bookmark = -1;

      x = 0;

      while(flag == 0){
	/* searching for the next open mail slot in a box  */
	if(mailbox[mbxID].mail[x][0] == '\0'){
	  printk("Send: empty mail slot found\n");
	  flag = 1;
	  bookmark = x;
	}
	
	x++;
	
	if(x < 128 && flag == 0){
	  /* continue */
	} else {
	  flag = 1; /* necessary in case empty mailbox not found */
	  /* either free spot found or mailbox full */
	}  
      }
    }

  if(bookmark == -1){
    /* wasn't found */
    printk("send: mail slot not found\n");
    up_write(&semaphore);

    return 0;
  } else {
    /* empty mail slot found  */

    /*
      change this to a loop
     */
    /*
      strcpy(mailbox[mbxID].mail[bookmark], tmsg);
    */
    int count = 0;
    printk("Send/tmsg: once more - %s\n", tmsg);
    for(x = 0; x < N; x++){
      mailbox[mbxID].mail[bookmark][x] = tmsg[x];
      count++;
    }

    for(x = count; x < 512; x++){
      mailbox[mbxID].mail[bookmark][x] = '\0';
    }

    printk("Send: print final - %s\n", &mailbox[mbxID].mail[bookmark][0]);

    up_write(&semaphore);

    return N;
  }
}

/*
  requires access_ok and
  copy_from_user/copy_to_user
 */
asmlinkage long sys_receiveMsg421(unsigned long mbxID, char *msg,
				  unsigned long N, unsigned char flag)
{
  struct rw_semaphore semaphore;
  
  char tmsg[512];

  int x = 0;
  int y = 0;
  int nullFlag = 0;
  int sizeSent = 0;
  int nullCheck = 0;  

  init_rwsem(&semaphore);
  
  down_write(&semaphore);
  
  if(N < 0 || N > 512){
    printk("Receive: Improper N. N > 0 && N <= 512\n");

    up_write(&semaphore);

    return 0;
  }

  for(x = 0; x < 512; x++){
    tmsg[x] = '\0';
  }

  printk("Receive: tmsg initialized\n");

  /* check mailbox exists*/  
  if(mbxID < 0 || mbxID > 255){
    /*   Invalid ID */ 
    printk("Receive: Invalid ID\n");

    up_write(&semaphore);

    return 0;
  } else {
    
    if(mailbox[mbxID].open != 1 || mailbox[mbxID].mail[0][0] == '\0') {
      /*  mailbox closed or mailbox empty */
      up_write(&semaphore);
      return 0;
    } else {
      /*  Mailbox Open message for reading */
      sizeSent = 0;
      /* read message from first mail slot */
      for(x = 0; x < N; x++) {
	if(nullFlag == 0){
	  
	  tmsg[x] = mailbox[mbxID].mail[0][x];
	 
	  if(mailbox[mbxID].mail[0][x] == '\0'){
	    /* end of message stop copying record size */
	    printk("Receive: message retrieved\n");
	    nullFlag = 1;
	    sizeSent = x;
	  }
	  
	}
      }

      if(sizeSent == 0){
	nullCheck = N;
      } else {
	nullCheck = sizeSent;
      }

      for(x = nullCheck; x < 512; x++){
	tmsg[x] = '\0';
      }
      
      printk("receive/tmsg ready: %s\n", tmsg);
    }
    
    /*
      changed tmsg to &tmsg

      it's here. my copy_to_user is doing something wrong.
     */
    if(access_ok(VERIFY_WRITE, msg, sizeof(char) * N) != 0){
      printk("Receive: access ok\n");
      printk("Receive/tmsg: %s\n", tmsg);
      copy_to_user(msg, &tmsg, sizeof(char) * N);
      printk("Receive/msg: %s\n", msg);
      printk("Receive: after copy to user\n");
      
      /*   Testing the copy_to_user */

      if(flag != 0){
	printk("Receive/flag!=0\n");
	/*  nonzero flag == erase shifting over */
	for(x = 0; x < 127; x++){
	  for(y = 0; y < 512; y++){
	    mailbox[mbxID].mail[x][y] = mailbox[mbxID].mail[x+1][y];
	    /* overwrite with next message in the list */ 
	  }
	}
	
	for(x = 0; x < 512; x++){
	  /*  blank out last mail box */
	  mailbox[mbxID].mail[127][x] = '\0';
	}
      } else {
	printk("Receive/flag == 0\n");
      }
      
      

      up_write(&semaphore);
      
      return sizeSent;
      

    } else {
      printk("Receive: access not ok\n");
      /* access not ok */  
      up_write(&semaphore);
      return 0;
    }
  }
  
  printk("Receive: Invalid ID\n");
  
  up_write(&semaphore);

  return 0;
}

asmlinkage long sys_countMsg421(unsigned long mbxID)
{
 /* counts the number of messages in a mailbox */

  struct rw_semaphore semaphore;

  int x = 0;
  int counter = 0;

  init_rwsem(&semaphore);

  down_write(&semaphore);

  if(mbxID < 0 || mbxID > 255){
    printk("Count: Invalid mbxID\n");

    up_write(&semaphore);

    return 0;
  }
  
  if(mailbox[mbxID].open == 1){
  
    for(x = 0; x < 128; x++){
      if(mailbox[mbxID].mail[x][0] != '\0'){
	/* there's a message */
	counter++;
      }
    }
  }
  
  up_write(&semaphore);

  return counter;
}
