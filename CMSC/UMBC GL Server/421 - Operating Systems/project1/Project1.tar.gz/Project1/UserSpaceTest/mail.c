#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* char *array[256][129]; */
struct mailBox
{
  int open;
  /*
    [128] mailbox numbers
    [512] string numbers
  */
  char mail[128][512];
};

struct mailBox mailbox[256];

long mkMbox421(unsigned long mbxID)
{
  if(mbxID < 0 || mbxID > 255){
    /* invalid ID */
    return 1;
  }
  
  /* check if mailbox already open */

  mailbox[mbxID].open = 1;

  int x = 0, y = 0;

  /* initialize the members */
  for(x = 0; x < 128; x++){
    for(y = 0; y < 512; y++){
      mailbox[mbxID].mail[x][y] = '\0'; 
    }
  }
  
  /* array[mbxID][0] = "OPEN"; */
  
  return 0;
}

long rmMbox421(unsigned long mbxID)
{
  if(mbxID < 0 || mbxID > 255){
    /* Invalid ID */
    return 1;
  }
  

  if(mailbox[mbxID].open == 1){
    /* mailbox open check for still existing mail */
    if(mailbox[mbxID].mail[0][0] == '\0'){
      /* mailbox empty */
      mailbox[mbxID].open = 0;
    }
  } 

  return 0;
}

/*
  Shift the elements for a given row
*/
void shiftElements(unsigned long mbxID)
{
  int x = 0;
  int y = 0;

  /* to 127. last row will just be blown out with '\0' */
  for(x = 0; x < 127; x++){
    for(y = 0; y < 512; y++){
      mailbox[mbxID].mail[x][y] = mailbox[mbxID].mail[x+1][y];
      /* overwrite with next message in the list */
    }
  }
  
  for(x = 0; x < 512; x++){
    /* blank out last mail box */
    mailbox[mbxID].mail[127][x] = '\0';
  }

}


/*
  How do you return the count
 */
long countMbox421()
{
  int x = 0;
  int counter = 0;
  for(x = 0; x < 256; x++){
    if(mailbox[x].open == 1){
      /* Possible options: NULL or OPEN */
      counter++;
    }
  }

  return counter;
}

long listMbox421(unsigned long *mbxList, unsigned long K)
{
  
  int x = 0;
  int counter = 0;
  for(x = 0; x < 256; x++){
    /* only check if I don't exceed the given limit */
    if(counter < K){
      /* Mailbox exists */
      if(mailbox[x].open == 1){
	/* X by nature matches the ID  */
	mbxList[counter] = x;
	/* printf("%d \n", x); */
	counter++;
      }
    }
  }
  
  return counter;
}

long sendMsg421(unsigned long mbxID, char *msg, unsigned long N)
{
  int bookmark = 0;
  /* check mailbox exists */
  if(mbxID < 0 || mbxID > 255) {
    /* Invalid ID  */
    return 0;
  } else
    if(mailbox[mbxID].open != 1) {
      /* Mailbox Closed Can't send  */
    } else {
      /*
	ID Valid and Mailbox OPEN
	check for open space in mailbox
      */
      /* x becomes 1 at start of loop */
      int x = 0;
      int flag = 0;
      bookmark = -1;
      while(flag == 0){
	
	if(mailbox[mbxID].mail[x][0] == '\0'){
	  flag = 1;
	  bookmark = x;
	}

	x++;

	if(x < 128 && flag == 0){
	  /* continue */
	} else {
	  flag = 1; /* necessary in case empty mailbox not found */
	  /* either free spot found or mailbox full */
	}  
      }
    }

  if(bookmark == -1){
    /* wasn't found */
    /*printf("wasn't found\n");*/
    return 0;
  } else {
    /* empty mail slot found  */
    /*printf("empty mail slot found\n");*/
    int y = 0;
    char rawr[12];
    /*printf("bookmark: %d\n", bookmark);
      printf("msg: %s\n", msg);*/
    for(y = 0; y < N; y++){
      /*printf("%d\n", y);*/
      rawr[y] = msg[y];
      strcpy(mailbox[mbxID].mail[bookmark], msg);
    }
    /*printf("rawr: %s\n", rawr);
    printf("mail: %s\n", mailbox[mbxID].mail[bookmark]);
    */
    return N;
  }
  
}

long receiveMsg421(unsigned long mbxID, char *msg, unsigned long N, unsigned char flag)
{
  /* check mailbox exists*/  
  if(mbxID < 0 || mbxID > 255){
    /*   Invalid ID */ 
  } else {
    
    if(mailbox[mbxID].open != 1 || mailbox[mbxID].mail[0][0] == '\0') {
      /*  mailbox closed or mailbox empty */ 
    } else {
      /*  Mailbox Open message for reading */
      int x = 0;
      int nullFlag = 0;
      int sizeSent = 0;
      /* read message from first mail slot */
      for(x = 0; x < N; x++) {
	if(nullFlag == 0){
	  msg[x] = mailbox[mbxID].mail[0][x];
	  if(mailbox[mbxID].mail[0][x] == '\0'){
	    /* end of message stop copying record size */
	    nullFlag = 1;
	    sizeSent = x;
	  }
	}
      }

      if(flag != 0){
	/* nonzero flag == erase */
	shiftElements(mbxID);
      }

      return x;

    }
    
  }
  
  return 0;
}

long countMsg421(unsigned long mbxID)
{
  /* counts the number of messages in a mailbox */

  int x = 0;
  int counter = 0;
  
  if(mailbox[mbxID].open == 1){
  
    for(x = 0; x < 128; x++){
      if(mailbox[mbxID].mail[x][0] != '\0'){
	/* there's a message */
	counter++;
      }
    }
  }
  
  return counter;
}
 
int main(int argc, char **argv)
{
   /* 
     char * array as a global variable is all nulled out
   */
  int count = 0;

  int sent = 0;

  mkMbox421(41);

  count = countMsg421(41);

  printf("count: %d\n", count);

  sent = sendMsg421(41, "hello\0", strlen("hello\0"));

  count = countMsg421(41);

  printf("count: %d\n", count);
 
  return 0;
}
