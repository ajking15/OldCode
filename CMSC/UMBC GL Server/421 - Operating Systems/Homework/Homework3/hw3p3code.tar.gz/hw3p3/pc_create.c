/*
  pc_create.c
  Christopher Mai
 */

#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

extern int errno;

int shmid;
double *doubleArray;
int size;

#define SEMAPHORE_KEY 2010
#define NUM 1
int semid;
struct sembuf lock_sem_var = {0, -1, IPC_NOWAIT};
struct sembuf ulock_sem_var = {0, 1, IPC_NOWAIT};

union semun {
	int val;
	struct semid_ds *buf;
	unsigned short int *array;
	struct seminfo *__buf;
};

int semExist(){
  if((semid = semget(SEMAPHORE_KEY, NUM, 0666)) < 0){
    /*printf("Check: Error in shmget. errno is: %d\n", errno);*/
    /*
      printf("Semaphore doesn't Exist\n");
      printf("Creating new semaphore\n");
    */
    /* no access doesn't exist  */
    return -1;
  } else {
    /* could access meaning it already exists  */
    printf("Semaphore Already Exists\n");
    return 0;
  }
  
}

/* only create will have the IPC_CREAT */
void init_semaphore()
{
  if(semExist() == -1){
    if((semid = semget(SEMAPHORE_KEY, NUM, 
		       IPC_CREAT | 0666)) < 0) {
      printf("semget error: errno is %d\n", errno);
      exit(1);
	}
  } else {
    /* semaphore already exists. also means segment still exists */
  }
}



void set_sem_val()
{
	union semun semopts;
	semopts.val = 1;
	semctl(semid, 0, SETVAL, semopts);
}

int semaphore_lock(int flag)
{
  int sem = 0;
  lock_sem_var.sem_num = flag;
  while(sem == 0) {
  if((sem = semop(semid, &lock_sem_var, 1)) == -1) {
    /*return -1;*/
  } else {
    sem = 1;
  }
  }
  return 0;
}

int semaphore_unlock(int flag)
{
	ulock_sem_var.sem_num = flag;
	if(semop(semid, &ulock_sem_var, 1) == -1) {
		printf("unlock error. errno is %d flag is %d\n", errno, flag);
		return -1;
	}
	return 0;
}

void remove_semaphore()
{
	semctl(semid, 0, IPC_RMID);
}


int checkExist(int numDoubles){
  if((shmid = shmget(9999, numDoubles, 0666)) < 0){
    /*printf("Check: Error in shmget. errno is: %d\n", errno);*/
    printf("Segment doesn't Exist\n");
    printf("Creating new segment\n");

    /* no access doesn't exist  */
    return -1;
  } else {
    /* could access meaning it already exists  */
    printf("Segment Already Exists\n");
    return 0;
  }
  
}

int create(int numDoubles) {
  if((shmid = shmget(9999, numDoubles, IPC_CREAT | 0666)) < 0) {
    printf("Create: Error in shmget. errno is: %d\n", errno);
    
    return -1;
  }
 
  /*
    write out a file. with numDoubles 
   */
  FILE *file;

  file = fopen("size.txt", "w");
  size = numDoubles;

  if(file != NULL) {
    /* worked */
    fprintf(file, "%d", numDoubles);
    fclose(file);
  } else {
    /* failed */
    return -1;
  }
  

  if((doubleArray = shmat(shmid, NULL, 0)) < 0) {
    printf("Error in shm attach. errno is: %d\n", errno);

    return -1;
  } else {
    int x = 0;
    for(x = 0; x < size; x++) {
      doubleArray[x] = 0.0;
    }
  }

  if(shmdt(doubleArray) < 0) {
    printf("Error in shmdt. errno is: %d\n", errno);

    return -1;
  }

  return 0;
}

int main(int argc, char **argv)
{
  /* takes in 1 number. argv[1] because argv[0] is the script name  */
  if(argc != 2) {
    printf("Invalid Number of cmd line args.\n");
	   
    return 0;
  }

  init_semaphore();
  set_sem_val();
  semaphore_lock(0);
  /* won't create a new segment when one exists */
  if(checkExist(atoi(argv[1])) < 0){
    create(atoi(argv[1]));
  }
  semaphore_unlock(0);
  /* remove_semaphore();*/

  return 0;
}
