/*
  consumer.c
  Christopher Mai
  
 */

#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

extern int errno;

int shmid;
double *doubleArray;
int size;

#define SEMAPHORE_KEY 2010
#define NUM 1
int semid;
struct sembuf lock_sem_var = {0, -1, IPC_NOWAIT};
struct sembuf ulock_sem_var = {0, 1, IPC_NOWAIT};

union semun {
	int val;
	struct semid_ds *buf;
	unsigned short int *array;
	struct seminfo *__buf;
};

void init_semaphore()
{
	if((semid = semget(SEMAPHORE_KEY, NUM, 0666)) < 0) {
		printf("semget error: errno is %d\n", errno);
		exit(1);
	}
}

void set_sem_val()
{
	union semun semopts;
	semopts.val = 1;
	semctl(semid, 0, SETVAL, semopts);
}

int semaphore_lock(int flag)
{
  int sem = 0;
  lock_sem_var.sem_num = flag;
  while(sem == 0) {
    if((sem = semop(semid, &lock_sem_var, 1)) == -1) {
      /*return -1;*/
      
    } else {
      sem = 1;
    }
  }
  return 0;
}

int semaphore_unlock(int flag)
{
	ulock_sem_var.sem_num = flag;
	if(semop(semid, &ulock_sem_var, 1) == -1) {
		printf("unlock error. errno is %d flag is %d\n", errno, flag);
		return -1;
	}
	return 0;
}

int accessMem(){
  FILE *file;

  file = fopen("size.txt", "r");

  if(file != NULL) {
    /* worked */
    fscanf(file, "%d", &size);
    fclose(file);
  } else {
    /* failed */
    return -1;
  }

  if((shmid = shmget(9999, size, 0666)) < 0) {
    printf("Error in shmget. errno is: %d\n", errno);

    return -1;
  } 

  return 0;
  
}

int consume() {
  int x = 0;
  int flag = 0;

  if((doubleArray = shmat(shmid, NULL, 0)) < 0) {
    printf("Error in shmat. errno is: %d\n", errno);

    return -1;
  }

  while(x < size && flag == 0) {
    if(doubleArray[x] == 0) {
      /* empty spot in previous. check for array oob */
      
      flag = 1;
      if(x == 0.0){
	/* nothing to consume */
	doubleArray[x] = 1.0;
	
	flag = -2;
      } else {
	/* [x - 1] = 1  */
	/*printf("Deleted\n"); */
	doubleArray[x - 1] = 0.0;
	/* fifo for convenience. */
	flag = 1;
      }
    }

   

    if(x == (size - 1)) {
      /* printf("Full\n"); */

      doubleArray[x] = 0.0;
      flag = 1;
    }

    x++;
  }
  /* should never be 0 */
  /* shm will either be empty or have things in it */
  if(flag == 0) {
    flag = -1;
  }

  shmdt(doubleArray);

  return flag;

}

void print() {
  if((doubleArray = shmat(shmid, NULL, 0)) < 0) {
    printf("Error in shmat. errno is: %d\n", errno);
    
   
  }
  
  int x = 0;
  printf("array: \n");
  for(x = 0; x < size; x++){
    printf("[%d] =  %f \n", x, doubleArray[x]);
  }


   shmdt(doubleArray);
}

int main(int argc, char **argv)
{
  if(argc != 3) {
    printf("Invalid number of cmd line args\n");

    return 0;
  }
  int x = 0;
  int cons = atoi(argv[1]);
  int wait = atoi(argv[2]);

  init_semaphore();
  set_sem_val();

  accessMem();

  while(x < cons) {
    semaphore_lock(0);
    if(consume() == -2){
      /* empty */
    } else {
      /* something consumed */
      x++;
      sleep(wait);
    }
    semaphore_unlock(0);
   
  }
  print();

  return 0;
}
