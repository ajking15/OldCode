/*
  producer.c
  Christopher Mai
 */

#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

extern int errno;

int shmid;
double *doubleArray;
int size;

#define SEMAPHORE_KEY 2010
#define NUM 1
int semid;
struct sembuf lock_sem_var = {0, -1, IPC_NOWAIT};
struct sembuf ulock_sem_var = {0, 1, IPC_NOWAIT};

union semun {
	int val;
	struct semid_ds *buf;
	unsigned short int *array;
	struct seminfo *__buf;
};

void init_semaphore()
{
	if((semid = semget(SEMAPHORE_KEY, NUM, 0666)) < 0) {
		printf("semget error: errno is %d\n", errno);
		exit(1);
	}
}

void set_sem_val()
{
	union semun semopts;
	semopts.val = 1;
	semctl(semid, 0, SETVAL, semopts);
}


int semaphore_lock(int flag)
{
  int sem = 0;
  lock_sem_var.sem_num = flag;
  while(sem == 0) {
    if((sem = semop(semid, &lock_sem_var, 1)) == -1) {
      /*return -1;*/
      
    } else {
      sem = 1;
    }
  }
  return 0;
}

int semaphore_unlock(int flag)
{
	ulock_sem_var.sem_num = flag;
	if(semop(semid, &ulock_sem_var, 1) == -1) {
		printf("unlock error. errno is %d flag is %d\n", errno, flag);
		return -1;
	}
	return 0;
}

int accessMem(){
  

  FILE *file;

  file = fopen("size.txt", "r");

  if(file != NULL) {
    /* worked */
    fscanf(file, "%d", &size);
    fclose(file);
    /* printf("Size: %d\n", size); */
    
 
  } else {
    /* failed */
    return -1;
  }
  if((shmid = shmget(9999, size, 0666)) < 0) {
      printf("Error in shmget. errno is: %d\n", errno);

      return -1;
  }
  
  return 0;
  
}

int produce() {
  /*
    put a 1 in the first open spot
   */
  int x = 0;
  int flag = 0;

  if((doubleArray = shmat(shmid, NULL, 0)) < 0) {
    printf("Error in shm attach. errno is: %d\n", errno);
    
    return -1;
  }

 

  while(x < size && flag == 0) {
    /* printf("X: %d  [x] %f\n", x, doubleArray[x]); */
    if(doubleArray[x] == 0.0) {
      /* empty spot  */
      doubleArray[x] = 1.0;
      flag = 1;
      /*printf("Empty spot found. flag = 1\n");*/
    } else {
      /*printf("Something there\n"); */
    }

    x++;

  }
 
  shmdt(doubleArray);
  
  if(flag == 0) {
    /* full */
    return -2;
  } else {
    /* empty spot found */
    return 0;
  }

}

void print() {
  if((doubleArray = shmat(shmid, NULL, 0)) < 0) {
    printf("Error in shmat. errno is: %d\n", errno);
    
   
  }
  
  int x = 0;
  printf("array: \n");
  for(x = 0; x < size; x++){
    printf("[%d] =  %f\n", x, doubleArray[x]);
  }


   shmdt(doubleArray);
}

int main(int argc, char **argv)
{
  if(argc != 3) {
    printf("Invalid number of cmd line args\n");

    return 0;
  }
  
  int x = 0;
  int prod = atoi(argv[1]);
  int wait = atoi(argv[2]);

  init_semaphore();
  set_sem_val();
  
  if(accessMem() < 0){
    return 0;
  }

  /* print(); */

  
  
  /* printf("Wait: %d\n", wait); */

  while(x < prod) {
    semaphore_lock(0);
    if(produce() == -2){
      
    } else {
      x++;
      sleep(wait);
     
    }
    semaphore_unlock(0);
    
  }

  print();

  return 0;
}
