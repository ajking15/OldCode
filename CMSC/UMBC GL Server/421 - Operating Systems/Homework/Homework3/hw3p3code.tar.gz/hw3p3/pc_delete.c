/*
  pc_delete.c
  Christopher Mai
 */

#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

extern int errno;

int shmid;

#define SEMAPHORE_KEY 2010
#define NUM 1
int semid;
struct sembuf lock_sem_var = {0, -1, IPC_NOWAIT};
struct sembuf ulock_sem_var = {0, 1, IPC_NOWAIT};

union semun {
	int val;
	struct semid_ds *buf;
	unsigned short int *array;
	struct seminfo *__buf;
};

void init_semaphore()
{
	if((semid = semget(SEMAPHORE_KEY, NUM, 0666)) < 0) {
		printf("semget error: errno is %d\n", errno);
		exit(1);
	}
}

void set_sem_val()
{
	union semun semopts;
	semopts.val = 1;
	semctl(semid, 0, SETVAL, semopts);
}


int semaphore_lock(int flag)
{
  int sem = 0;
  lock_sem_var.sem_num = flag;
  while(sem == 0) {
    if((sem = semop(semid, &lock_sem_var, 1)) == -1) {
      /*return -1;*/
      
    } else {
      sem = 1;
    }
  }
  return 0;
}

int semaphore_unlock(int flag)
{
	ulock_sem_var.sem_num = flag;
	if(semop(semid, &ulock_sem_var, 1) == -1) {
		printf("unlock error. errno is %d flag is %d\n", errno, flag);
		return -1;
	}
	return 0;
}

void remove_semaphore()
{
	semctl(semid, 0, IPC_RMID);
}


int delete() {
  /* Should I check if it's empty */
  if((shmid = shmget(9999, 5, 0666)) < 0){
    /* get the ID and delete using shmctl  */
    printf("Error in shmget. errno is: %d\n", errno);

    return -1;
  }

  shmctl(shmid, IPC_RMID, NULL);

  return 0;
}

int main(int argc, char **argv)
{
  if(argc != 1) {
    printf("Invalid number of cmd line args\n");

    return 0;
  }
  init_semaphore();
  set_sem_val();
  semaphore_lock(0);

  delete();
  
  semaphore_unlock(0);
  /* only delete removes the semaphore */
  remove_semaphore();


  return 0;
}
