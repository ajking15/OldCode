#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>
#include <malloc.h>

int **matrix;
int *vector;
int *result;
int rows;
int cols;
int wait;
int busy;
int sec;
float nsec;

#define handle_error(msg) \
  do { perror(msg); exit(EXIT_FAILURE); } while (0)

static void pclock(char *msg, clockid_t cid) {
  struct timespec ts;

  /* printf("%s", msg); */
  if(clock_gettime(cid, &ts) == -1){
    handle_error("clock_gettime");
  }
  /* printf("%10d.%06ld\n", (int) ts.tv_sec, ts.tv_nsec / 1000000); */

  sec = (int)ts.tv_sec + sec;

  nsec = nsec + ts.tv_nsec / 1000000;
}

void recordTimes(int sec, long int nsec) {
  
}

void *mt_multiply(void *threadid)
{
  /* busy waiting seems to do the trick  */
  while(busy == 0);
  busy = 0;
  long vRow;

  vRow = (long)threadid;
  /*printf("vRow %ld\n", vRow);*/
  pthread_mutex_t lock;
  pthread_mutex_init(&lock,NULL);
  /* each thread should wait until it gets a lock to proceed  */
  /* ^ apparently not so busy waiting it is */
  pthread_mutex_lock(&lock);

  int x = 0;
  if(result == NULL) {
    /* printf("Result is NULL\n"); */
    result = malloc(sizeof(int *) * rows);

    for(x = 0; x < cols; x++) {
      result[x] = 0;
    }
  } else { 
    /* printf("Result != NULL\n"); */
  }

  int temp;

 
  /* this does vector math for an entire array  */
 
  temp = 0;
  for(x = 0; x < cols; x++) {
    temp = (matrix[vRow][x] * vector[x]) + temp; 
  }
  
  result[vRow] = temp;
  wait++;
  pthread_mutex_unlock(&lock);
  busy = 1;
  pthread_exit(NULL);
}

int read_matrix(char *fileName)
{
  /*  printf("Read Matrix\n"); */
  FILE *file;
  /* printf("File Name: %s\n", fileName); */
  file = fopen(fileName, "r");
  if(file != NULL){
    /* use fscanf  */
    
    /* read in array sizes */
    fscanf(file, "%d %d", &rows, &cols); 
			     
    int x = 0;
    int y = 0;
    
    matrix =  malloc(sizeof(int *) * rows);

    for(x = 0; x < rows; x++) {
      matrix[x] = malloc(sizeof(int *) * cols);
    }

    for(y = 0; y < rows; y++) {
      for(x = 0; x < cols; x++) {
	fscanf(file, "%d", &matrix[y][x]); 
      }
      /*      printf("\n"); */
    } 
      
 
    /* printf("Matrix: File Open\n"); */
    /* read in rows and columns then fill out array */
    fclose(file);
    /* printf("\n");*/
    return 1;
  } else {
    printf("Matrix: File open failed\n");

    return -1;
  }

}

int read_vector(char *fileName)
{
  /*
    read in appropriate array data from file
   */
  FILE *file;
  int vCol;
  int x = 0;

  file = fopen(fileName, "r");

  if(file != NULL) {
    /* Success */
    fscanf(file, "%d", &vCol);
    if(vCol != cols) {
      printf("Vector and Matrix columns don't match\n");
      
      return -1;
    }

    vector = malloc(sizeof(int *) * cols);

    for(x = 0; x < cols; x++) {
      fscanf(file, "%d", &vector[x]);
    }
    fclose(file);
    return 1;
  } else {
    /* Fail */
    return -1;
  }
}

int write_vector(char *fileName)
{
  FILE *file;
  int x = 0;
  file = fopen(fileName, "w");

  if(file != NULL) {
    /* File Open */
    fprintf(file, "%d\n", rows);
    
    for(x = 0; x < rows; x++){
      fprintf(file, "%d\n", result[x]);
    }

    fclose(file);
  } else {
    /* File Closed */
    printf("File Write: can't open\n");
  }

  return 1;
}

void print_matrices()
{
  int x = 0;
  int y = 0;

  if(matrix != NULL) {
    printf("Matrix Begin: \n");
    for(y = 0; y < rows; y++) {
      for(x = 0; x <cols; x++) {
	printf(" %d", matrix[y][x]); 
      }
      printf("\n"); 
    }
    printf("Matrix End\n");
  }

  if(vector != NULL) {
    printf("Vector Begin: \n");
    for(x = 0; x < cols; x++) {
      printf(" %d\n", vector[x]);
    } 
    printf("Vector Ends\n");
  }

  if(result != NULL) {
    printf("Result Begin: \n");
    for(x = 0; x < rows; x++) {
      printf(" %d\n", result[x]);
    }
  }
}

int main(int argc, char *argv[])
{
  /* printf("Main\n"); */
  /* start timer here  */
  /* argv[0] is script name  */
  /* read in a file */
  char *matrixFile = argv[1];
  char *vectorFile = argv[2];
  char *outputFile = argv[3];

  clockid_t cid;
   
 
  
  if(read_matrix(matrixFile) == 1 && read_vector(vectorFile) == 1) {
     pthread_t threads[rows];
     int rc;
     long t;
    
    wait = 0;
   
    busy = 1;
    
    /* end first timer? start second? */

    for(t = 0; t < rows; t++) {
      /* mt_multiply(x); */
      rc = pthread_create(&threads[t], NULL, mt_multiply, (void *)t);
      /*printf("%ld\n", t);*/
      if(rc){
	printf("ERROR; return code from pthread_create() is %d\n", rc);
	exit(-1);
      }
    }
    /*    printf("waiting"); */
    while(wait != rows) {
      /* p/rintf("."); */
    }
    /* end second? start third */
    
    write_vector(outputFile);

    sec = 0;
    nsec = 0;
    
    if(pthread_getcpuclockid(pthread_self(), &cid) != 0){
      printf("pthread_getcpuclockid");
  }
    
    pclock("Main thread CPU time : ", cid); 
    
    for(t = 0; t < rows; t++) {
      if(pthread_getcpuclockid(threads[t], &cid) != 0) {
	/* printf("pthread_getcpuclockid\n"); */
	pclock("Thread CPU time: ", cid);
      }
    }
    
    printf("Second: %d\n", sec);
   printf("nsec: %f\n", nsec / 1000000);
   printf("Total: %f\n", (sec + nsec / 1000000));
   
   /*   printf("\n"); */
   /* print_matrices(); */ 
   /*  pthread_exit(NULL); */
  }

  /* store relevant data into proper matrices  */
  
  if(matrix != NULL) {
    free(matrix);
  }

  if(vector != NULL) {
    free(vector);
  }

  if(result != NULL) {
    free(result);
  }
  
  
   /* stop third */
   
   return 0;
}

/*
  Since I'm busy waiting. No threads should be running concurrently.
  therefore, I should be able to just run the one timer.
 */
/*
  without busy waiting some rows wouldn't get computed
 */
