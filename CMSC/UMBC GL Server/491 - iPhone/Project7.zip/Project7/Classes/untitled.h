//
//  untitled.h
//  Project7
//
//  Created by  on 11/8/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface untitled : UIView {

}

@end
