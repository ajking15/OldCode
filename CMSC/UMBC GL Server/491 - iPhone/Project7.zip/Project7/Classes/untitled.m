//
//  untitled.m
//  Project7
//
//  Created by  on 11/8/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "untitled.h"


@implementation untitled


- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}


- (void)dealloc {
    [super dealloc];
}


@end
