//
//  Project7ViewController.h
//  Project7
//
//  Created by  on 11/8/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 Project7ViewController
	Towards the end of this project I realized I probably should have done most of the logic in here.
	However, under current design this does nothing a UIViewController doesn't do by default.
 */
@interface Project7ViewController : UIViewController {
		
}
		   
@end

