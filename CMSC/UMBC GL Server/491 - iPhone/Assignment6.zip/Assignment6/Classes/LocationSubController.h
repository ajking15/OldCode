//
//  LocationSubController.h
//  Assignment6
//
//  Created by  on 11/2/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LocationSubController : UIViewController {

}

-(IBAction)returnToMap;

@end
