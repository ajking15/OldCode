//
//  ubuntu.h
//  Linux
//
//  Created by  on 12/12/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 only exists for the .xib
 */
@interface ubuntu : UIViewController {

}

@end
