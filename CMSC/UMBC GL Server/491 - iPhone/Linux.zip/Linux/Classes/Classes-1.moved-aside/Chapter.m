//
//  Chapter.m
//  Linux
//
//  Created by  on 12/5/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Chapter.h"


@implementation Chapter


- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}


- (void)dealloc {
    [super dealloc];
}


@end
